<?php 
function Rand_IP(){
    $ip1id= round(rand(600000, 2550000) / 10000); 
    $ip2id= round(rand(600000, 2550000) / 10000); 
    $ip3id= round(rand(600000, 2550000) / 10000);
    $ip4id= round(rand(600000, 2550000) / 10000);
    return $ip1id.".".$ip2id.".".$ip3id.".".$ip4id;
}
//curl获取内容Curl(网址,post内容,$Origin,$Referer,1返回源码2返回状态码,1post2get)
function Curl($url,$data,$Origin,$Referer,$zt,$fs){
        $user_agent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.66 Safari/537.36";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-FORWARDED-FOR:'.Rand_IP(), 'CLIENT-IP:'.Rand_IP())); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        curl_setopt($ch, CURLOPT_NOBODY, false);
        //curl_setopt($ch, CURLOPT_ORIGIN, $Origin); //构造来路 
        //curl_setopt($curl, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_REFERER, $Referer); //构造来路 
       if($fs==1){
        curl_setopt($ch, CURLOPT_POST, 1);//设置为POST方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
       };
        curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
        $temp = curl_exec($ch);
        $httpCode = curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($zt==1){
        return $temp;
        }elseif($zt==2){
        return $httpCode;
        };
}
$url=$_REQUEST['url'];
$http = array('url' => 'https://www.nxflv.com/apx.php', 'Origin' => 'https://www.nxflv.com/apx.php', 'Referer' => "https://www.nxflv.com/?url=" . $url);
$postData = http_build_query(array('url' => $url, 'referer' => base64_encode("https://www.nxflv.com/?url=" . $url), 'ref' => 0, 'time' => intval(time()), 'type' => "", 'other' => base64_encode($url), 'ios' => ""));
print_r(Curl($http['url'], $postData, $http['Origin'], $http['Referer'], 1, 1));
?>